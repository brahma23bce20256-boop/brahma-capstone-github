// ── Shared Types for RAG Knowledge Intelligence System ──

export interface QueryRequest {
  query: string;
  top_k?: number;
  temperature?: number;
}

export interface SourceDocument {
  id: string;
  filename: string;
  content: string;
  relevance: number;
  metadata: Record<string, unknown>;
}

export interface QueryResponse {
  answer: string;
  sources: SourceDocument[];
  confidence: number;
  processing_time_ms: number;
}

export interface DocumentIngest {
  id: string;
  filename: string;
  status: "processing" | "completed" | "error";
  chunks: number;
  vector_id?: string;
  error?: string;
}

export interface DocumentListItem {
  id: string;
  filename: string;
  file_type: string;
  size_bytes: number;
  status: string;
  chunks: number;
  vector_sync: number;
  category: string;
  word_count: number;
  created_at: string;
  updated_at: string;
}

export interface ConversationTurn {
  id?: string;
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
}

export interface Conversation {
  id?: string;
  title: string;
  turns: ConversationTurn[];
  created_at?: string;
  updated_at?: string;
}

export interface PatternDetection {
  pattern_id: string;
  trend_source: string;
  baseline_velocity: string;
  anomaly_score: number;
  status: "critical" | "monitoring" | "nominal";
}

export interface EntityItem {
  name: string;
  category: "Organization" | "Location" | "Person" | "Event";
  count: number;
}

export interface SourceItem {
  id?: string;
  name: string;
  source_type: "folder" | "api" | "database" | "s3";
  status: "active" | "syncing" | "error" | "archived";
  vector_sync_pct?: number;
  doc_count?: number;
  last_updated?: string;
}

export interface ApiKeyUpdate {
  provider: string;
  key: string;
}

export interface SystemStats {
  total_documents: number;
  total_entities: number;
  total_chunks: number;
  vector_space_health: number;
  daily_queries: number;
  active_clusters: number;
  avg_confidence: number;
  storage_used_gb: number;
  storage_total_gb: number;
  total_vectors: number;
  nodes_online: number;
  active_pipelines: number;
}

// ═════════════════════════════════════════════════════
// Data Mining Types (Semester Project)
// ═════════════════════════════════════════════════════

export interface FrequentItemset {
  items: string[];
  size: number;
  support: number;
  count: number;
}

export interface AssociationRule {
  antecedent: string[];
  consequent: string[];
  support: number;
  confidence: number;
  lift: number;
}

export interface AprioriResponse {
  frequent_itemsets: FrequentItemset[];
  association_rules: AssociationRule[];
  n_transactions: number;
}

export interface ClusterDocument {
  name: string;
  index: number;
}

export interface ClusterGroup {
  documents: ClusterDocument[];
  terms: string[];
  size: number;
}

export interface ClusteringResponse {
  clusters: ClusterGroup[];
  n_clusters: number;
  score: number;
}

export interface SentimentResult {
  filename: string;
  polarity: number;
  sentiment: string;
  confidence: number;
  positive_words: number;
  negative_words: number;
  total_words: number;
}
